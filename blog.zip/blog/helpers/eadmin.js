module.exports = {
     eadmin:function(req,res,next){
        if(req.isAuthenticated() && req.user.eadmin == 1){
        
              return next()   //se admin 
        }
        req.flash('error_msg','Você precisa ser admin para ter acesso') //se não admin
        res.redirect('/')
     }
}