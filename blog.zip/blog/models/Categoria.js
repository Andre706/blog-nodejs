const mongoose = require('mongoose')

//define schema para collection
const Categoria = mongoose.Schema({
    nome: {
        type: String,
        required:true
    },
    slug:{
        type:String,
        required:true
    },
    data: {
        type:Date,
        default:Date.now()
    }
})

mongoose.model("categorias",Categoria) //cria collection