const mongoose = require('mongoose')

//define schema para collection
const Usuario = mongoose.Schema({
    nome: {
        type: String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    senha: {
        type:String,
        required:true
    },
    eadmin:{
        type:String,
        default:0
    }
})

mongoose.model("usuarios",Usuario) //cria collection