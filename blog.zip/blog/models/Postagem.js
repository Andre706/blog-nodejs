const mongoose = require('mongoose')

//define schema para collection
const Postagem = mongoose.Schema({
    titulo: {
        type: String,
        required:true
    },

    slug:{
        type:String,
        required:true
    },

    descricao:{
        type:String,
        required:true
    },

    conteudo:{
        type:String,
        required:true
    },

    categoria:{
       type:String,
       required:true
    },

    data: {
        type:Date,
        default:Date.now()
    }
})

mongoose.model("postagens",Postagem) //cria collection