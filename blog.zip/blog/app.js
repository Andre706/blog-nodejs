const express = require('express')
const app = new express();
const mongoose = require('mongoose')
const handlebars = require('express-handlebars')
const bodyParser = require('body-parser');
const admin = require('./rotas/admin')
const path = require('path')
const session = require('express-session')
const flash = require('connect-flash')
require('./models/Postagem')
const Postagem = mongoose.model('postagens') 
require('./models/Categoria') 
const Categoria = mongoose.model('categorias') 
require('./models/Usuario')
const Usuario = mongoose.model('usuarios') 
const bcrypt = require('bcryptjs');
const passport = require('passport');
require('./config/auth')(passport)
const {elogin} = require('./helpers/elogin')  //recebe função do objeto elogin que controlará o acesso a uma rota
var eadmin=null

//configuração session
app.use(session({
  secret:"bgddtdg",
  resave:true,
  saveUninitialized:true
})) 

//configuração passport
app.use(passport.initialize())
app.use(passport.session())

//configuração flash
app.use(flash())

//configuração Midleware
app.use((req,res,next)=>{
   //criação de variáveis globais
   res.locals.success_msg = req.flash('success_msg')
   res.locals.error_msg = req.flash('error_msg')
   res.locals.error = req.flash('error')
   res.locals.user = req.user || null
   res.locals.eadmin = eadmin
   next()
})

//configuração handlebars
app.engine('handlebars',handlebars({defaultLayout:'main'}))
  app.set('view engine','handlebars')


//configuração body-parser
app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())

//Public
app.use(express.static(path.join(__dirname,'public')));

//rotas
app.get('/',(req,res)=>{
  Postagem.find().then((postagens)=>{
    res.render('home',{postagens: postagens.map(Postagem => Postagem.toJSON())})
  })
 
})

app.get('/postagem/:id',elogin,(req,res)=>{    //usuario precisa logar
   Postagem.findOne({_id:req.params.id}).then((postagem)=>{
      res.render('postagem',{postagem:postagem.toJSON()})
   }).catch((err)=>{
     req.flash('error_msg','Postagem não encontrada')
     res.redirect('/')
   })
})

app.get('/categorias',elogin,(req,res)=>{     //usuario precisa logar
   Categoria.find().then((categorias)=>{
     res.render('categorias',{categorias:categorias.map(Categoria => Categoria.toJSON())})
   })
   
})

app.get('/categoria/:nome',(req,res)=>{
   Postagem.find({categoria:req.params.nome}).then((postagens)=>{
     res.render('categoria',{postagens: postagens.map(Postagem => Postagem.toJSON())})
   }).catch((err)=>{
     req.flash('error_msg','Categoria não encontrada')
     res.redirect('/')
   })
})

app.get('/registro',(req,res)=>{
   res.render('registro')
  
})

app.post('/registro/addusuario',(req,res)=>{
   var erros = validaCampos(req)
   
  if(erros.length>0){
     res.render('registro',{erros:erros})
    }
   
   else{
      Usuario.findOne({email:req.body.email}).then((usuario)=>{
      if(usuario){
       
       req.flash('error_msg','Email já cadastrado')
       res.redirect('/registro')
      }
    })
    
        const usuario = {
         nome:req.body.nome,
         email:req.body.email,
         senha:req.body.senha
        
      }
      
      bcrypt.genSalt(10,(erro,salt)=>{      //gera hash para senha
          bcrypt.hash(usuario.senha,salt,(erro,hash)=>{
            if(erro){
              req.flash('error_msg','Falha ao cadastrar usuario')
              res.redirect('/')
            }
            usuario.senha=hash
            new Usuario(usuario).save().then(()=>{
              req.flash('success_msg','Usuário cadastrado com sucesso')
              res.redirect('/')
            }).catch((err)=>{
              req.flash('error_msg','Falha ao cadastrar usuario')
              res.redirect('/registro')
            })
          })
      }) 


    } 

})

app.get('/login',(req,res)=>{
  res.render('login')
})

app.post('/login/autentica',(req,res,next)=>{
   
   passport.authenticate('local',{
     successRedirect:'/',   //se autenticado
     failureRedirect:'/login', //se não autenticado
     failureFlash:true
   })(req,res,next)

   Usuario.findOne({email:req.body.email}).then((usuario)=>{
      
          if(usuario.eadmin==1){
             eadmin = 1
          }
          else{
             eadmin = null
          }
    })
})

app.get('/logout',(req,res)=>{
  req.logout()
  res.redirect('/')
})

app.use('/admin',admin)


//valida campos
function validaCampos(req){
  var  erros = []

  if(!req.body.nome || typeof req.body.nome == undefined || req.body.nome==null){
      erros.push({texto:'Nome inválido'})
  }
  
  if(!req.body.email || typeof req.body.email == undefined || req.body.email==null){
      erros.push({texto:'Email inválido'})
  }
  
  if(!req.body.senha || typeof req.body.senha == undefined || req.body.senha==null){
    erros.push({texto:'Senha inválida'})
  }
  
  if(req.body.senha.length <4){
      erros.push({texto:'Senha muito pequena'})
  }
  
  if(req.body.senha !=req.body.senha2){
    erros.push({texto:'Senha não confirmada'})
  }

    return erros
  

}

//estabelece conexão com banco de dados
const uri = 'mongodb+srv://blogapp:123@blogapp.cafdp.mongodb.net/<blog>?retryWrites=true&w=majority'
mongoose.connect(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('Conectado ao banco de dados')
})
.catch(err => console.log(err))

const PORT = process.env.PORT || 8990
app.listen(PORT,()=>{
    console.log("servidor rodando na porta 8990")
})


