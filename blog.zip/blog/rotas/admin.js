const express = require('express')
const router = express.Router()
const mongoose = require('mongoose')
require('../models/Categoria') //retorna collection criada
const Categoria = mongoose.model('categorias') //recebe referência de collection criada
require('../models/Postagem') //retorna collection criada
const Postagem = mongoose.model('postagens') //recebe referência de collection criada
const {eadmin} = require('../helpers/eadmin')  //recebe função do objeto eadmin que controlará o acesso a uma rota



//rotas de acesso exclusivo do admin

router.get('/categorias',eadmin, (req, res) => {
    Categoria.find().sort({data:'desc'}).then((categorias) => {          // find retorna todas as categorias existentes
        res.render('admin/categorias', {categorias:categorias.map(Categoria => Categoria.toJSON())})
    }).catch((error) => {
        console.log('houve um erro ao listar as categorias ' + erro)
        res.redirect('/admin')
    })
})

router.get('/categorias/add',eadmin,(req,res)=>{
    res.render("admin/addcategorias")
})

router.post('/categorias/nova',eadmin,(req,res)=>{
    var erros = []
    
    //verificação de preenchimento dos campos
    if(!req.body.nome || typeof req.body.nome == undefined || req.body.nome==null){
        erros.push({texto:'Nome inválido'})
   }

    if(!req.body.slug || typeof req.body.slug == undefined || req.body.slug==null){
        erros.push({texto:'Slug inválido'})
    }

    if(req.body.nome.length <2){
        erros.push({texto:'Nome da categoria é muito pequeno'})
    }
    
    
    if(erros.length>0){
        res.render('admin/addcategorias',{erros:erros})
    }
    else{
         const novaCategoria={

            nome:req.body.nome,
            slug:req.body.slug,
            data:req.body.data
         }
        
         //instancia novo doc
         new Categoria(novaCategoria).save().then(()=>{
            req.flash('success_msg','Categoria criada com sucesso')
            res.redirect('/admin/categorias')
         }).catch(()=>{
            req.flash('error_msg','Houve um erro ao criar a categoria,tente novamente') 
            res.redirect('/admin/categorias')
         })
    }
    
})

router.get('/categorias/edit/:id',eadmin,(req,res)=>{
    Categoria.findOne({_id:req.params.id}).then((categoriaEditavel)=>{
        res.render('admin/editcategorias',{categoria:categoriaEditavel.toJSON()})
    }).catch((err)=>{
        req.flash('error_msg','Esta categoria não existe')
        res.redirect('/admin/categorias')
    })
    
})

router.post('/categorias/edit',eadmin,(req,res)=>{
    Categoria.findOne({_id:req.body.id}).then((categoria)=>{
        categoria.nome=req.body.nome
        categoria.slug=req.body.slug
        categoria.save().then(()=>{
            req.flash('success_msg','Categoria editada com sucesso')
            res.redirect('/admin/categorias')
        }).catch(()=>{
            req.flash('error_msg','Falha na edição de categoria')
            res.redirect('/admin/categorias')
        })
    }).catch((err)=>{
        req.flash('error_msg','Esta categoria não existe')
        res.redirect('/admin/categorias')
    })
})

router.post('/categorias/deletar',eadmin,(req,res)=>{
    Categoria.remove({_id:req.body.id}).then(()=>{
        req.flash('success_msg','Categoria excluída com sucesso')
        res.redirect('/admin/categorias')
    }).catch((err)=>{
        req.flash('success_msg','Falha na exclusão de categoria')
        res.redirect('/admin/categorias')
    })
})

router.get('/postagens',eadmin,(req,res)=>{
    Postagem.find().then((postagens)=>{
        res.render('admin/postagens', {postagens: postagens.map(Postagem => Postagem.toJSON())})
    }).catch((err)=>{
        console.log(err)
    })
})


router.get('/postagens/add',eadmin,(req,res)=>{
    Categoria.find().then((categorias)=>{
        res.render('admin/addpostagens',{categorias: categorias.map(Categoria => Categoria.toJSON())})
    })
    
})

router.post('/postagens/nova',eadmin,(req,res)=>{
     const novaPostagem={
        titulo:req.body.titulo,
        slug:req.body.slug,
        descricao:req.body.descricao,
        categoria:req.body.categoria,
        conteudo:req.body.conteudo,
        data:req.body.data
    }
    new Postagem(novaPostagem).save().then(()=>{
        req.flash('success_msg','Postagem criada com sucesso')
        res.redirect('/admin/postagens')
    }).catch((err)=>{
        req.flash('error_msg','Falha na criação de postagem')
        res.redirect('/admin/postagens')
        console.log(err)
    })  

   
})


router.get('/postagens/edit/:id',eadmin,(req,res)=>{
     Postagem.findOne({_id:req.params.id}).then((postagem)=>{
         res.render('admin/editpostagens',{postagem:postagem.toJSON()})
     })
})

router.post('/postagens/edit',eadmin,(req,res)=>{
    Postagem.findOne({_id:req.body.id}).then((postagem)=>{
        postagem.titulo=req.body.titulo
        postagem.slug=req.body.slug
        postagem.descricao=req.body.descricao
        postagem.conteudo=req.body.conteudo
        postagem.categoria=req.body.categoria

        postagem.save().then(()=>{
            req.flash('success_msg','Postagem editada com sucesso')
            res.redirect('/admin/postagens')
        }).catch(()=>{
            req.flash('error_msg','Falha na edição de postagem')
            res.redirect('/admin/postagens')
        })
    }).catch((err)=>{
        req.flash('error_msg','Esta postagem não existe')
        res.redirect('/admin/postagens')
    })
})


router.post('/postagens/deletar/:id',eadmin,(req,res)=>{
    Postagem.remove({_id:req.params.id}).then(()=>{
        req.flash('success_msg','Postagem excluída com sucesso')
        res.redirect('/admin/postagens')
        
    }).catch((err)=>{
        req.flash('success_msg','Falha na exclusão de postagem')
        res.redirect('/admin/postagens')
       
    })
})



module.exports=router